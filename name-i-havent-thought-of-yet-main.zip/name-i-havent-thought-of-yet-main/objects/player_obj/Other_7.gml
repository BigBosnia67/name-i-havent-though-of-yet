if (sprite_index = player_death)
{
	sprite_index = player_right_idle_1;
	state = "normal";
	image_speed = 0;
    image_index = image_number - 1;
}
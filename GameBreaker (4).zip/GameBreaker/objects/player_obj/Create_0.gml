hsp = 0;
vsp = 0;
grv = 0.4;
walksp = 6;
jumpsp = -10;
accel = 0.3;
fric = 0.5;
wall_slide = false;
grounded = false;
alive = true;
default_skin = true;




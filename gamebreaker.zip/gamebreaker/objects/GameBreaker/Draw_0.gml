draw_text(x, y, "GameBreaker");
draw_text_transformed(x, y, "GameBreaker", 10,10,0);
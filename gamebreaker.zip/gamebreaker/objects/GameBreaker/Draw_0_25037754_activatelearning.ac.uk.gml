draw_text(x, y, "GameBreaker");
draw_text_transformed(x, y, "GameBreaker", 5,5,0);